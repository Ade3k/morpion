#Precquis
Node
MongoDB Atlas

#Installation

npm install

#Configuration
#Remplir le .env avec
TOKEN_SECRET=09f26e402586e2faa8da4c98a35f1b20d6b033c60
PWD_BD=VOTRE_MOT_DE_PASSE_DB
PWD_USER=VOTRE_USER_DB

#Lancer le serveur

node app.js

#Tester les api
http://localhost:3000/